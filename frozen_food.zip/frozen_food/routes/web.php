<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\StockMovementController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::resource('produk', ProductController::class)
        ->parameters(['produk' => 'product'])
        ->except('show');

    Route::get('/stok', [StockMovementController::class, 'index'])->name('stok.index');
    Route::get('/stok/grafik', [StockMovementController::class, 'grafik'])->name('stok.grafik');
    Route::get('/stok/{tipe}/create', [StockMovementController::class, 'create'])
        ->whereIn('tipe', ['masuk', 'keluar'])->name('stok.create');
    Route::post('/stok', [StockMovementController::class, 'store'])->name('stok.store');
});

require __DIR__ . '/auth.php';