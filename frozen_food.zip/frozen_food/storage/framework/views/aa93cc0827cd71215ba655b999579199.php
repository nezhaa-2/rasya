<?php $__env->startSection('title', $tipe === 'masuk' ? 'Barang Masuk' : 'Barang Keluar'); ?>
<?php $__env->startSection('content'); ?>
<h4 class="mb-3"><?php echo e($tipe === 'masuk' ? 'Catat Barang Masuk' : 'Catat Barang Keluar (Pengeluaran Produk)'); ?></h4>
<div class="card shadow-sm"><div class="card-body">
<form method="POST" action="<?php echo e(route('stok.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="tipe" value="<?php echo e($tipe); ?>">
    <div class="row g-3">
        <div class="col-md-8">
            <label class="form-label">Produk</label>
            <select name="product_id" id="product" class="form-select" required>
                <option value="">-- pilih produk --</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" data-harga="<?php echo e($tipe === 'masuk' ? $p->harga_beli : $p->harga_jual); ?>"
                        <?php if(old('product_id') == $p->id): echo 'selected'; endif; ?>>
                        <?php echo e($p->kode); ?> - <?php echo e($p->nama); ?> (stok: <?php echo e($p->stok); ?> <?php echo e($p->satuan); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Tanggal</label>
            <input type="date" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', now()->toDateString())); ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Alasan</label>
            <select name="alasan" class="form-select" required>
                <?php $__currentLoopData = $alasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(old('alasan') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Jumlah</label>
            <input type="number" min="1" name="jumlah" class="form-control" value="<?php echo e(old('jumlah')); ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Harga Satuan (Rp)</label>
            <input type="number" min="0" name="harga_satuan" id="harga" class="form-control" value="<?php echo e(old('harga_satuan')); ?>">
            <div class="form-text">Kosongkan untuk memakai harga <?php echo e($tipe === 'masuk' ? 'beli' : 'jual'); ?> produk.</div>
        </div>
        <div class="col-12">
            <label class="form-label">Keterangan</label>
            <input name="keterangan" class="form-control" maxlength="255" value="<?php echo e(old('keterangan')); ?>">
        </div>
    </div>
    <div class="mt-4">
        <button class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('stok.index')); ?>" class="btn btn-link">Batal</a>
    </div>
</form>
</div></div>

<script>
    // isi otomatis harga saat produk dipilih
    document.getElementById('product').addEventListener('change', function () {
        const h = this.selectedOptions[0]?.dataset.harga;
        if (h !== undefined) document.getElementById('harga').value = h;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/stok/create.blade.php ENDPATH**/ ?>