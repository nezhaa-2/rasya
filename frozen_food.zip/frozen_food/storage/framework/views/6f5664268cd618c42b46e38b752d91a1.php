<?php $__env->startSection('title', 'Riwayat Stok'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Riwayat Stok</h4>
    <div>
        <a href="<?php echo e(route('stok.create', 'masuk')); ?>" class="btn btn-success">+ Barang Masuk</a>
        <a href="<?php echo e(route('stok.create', 'keluar')); ?>" class="btn btn-secondary">+ Barang Keluar</a> <a href="<?php echo e(route('stok.grafik')); ?>" class="btn btn-outline-primary">Grafik Penjualan</a>
    </div>
</div>

<form method="GET" class="row g-2 mb-3">
    <div class="col-md-3">
        <select name="produk" class="form-select">
            <option value="">Semua produk</option>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>" <?php if(request('produk') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-2">
        <select name="tipe" class="form-select">
            <option value="">Semua tipe</option>
            <option value="masuk" <?php if(request('tipe') === 'masuk'): echo 'selected'; endif; ?>>Masuk</option>
            <option value="keluar" <?php if(request('tipe') === 'keluar'): echo 'selected'; endif; ?>>Keluar</option>
        </select>
    </div>
    <div class="col-md-2"><input type="date" name="dari" value="<?php echo e(request('dari')); ?>" class="form-control"></div>
    <div class="col-md-2"><input type="date" name="sampai" value="<?php echo e(request('sampai')); ?>" class="form-control"></div>
    <div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-6"><div class="alert alert-success mb-0">
        Total masuk: <strong><?php echo e(number_format($ringkas['masuk']->total_jumlah ?? 0, 0, ',', '.')); ?></strong> unit
        — Rp <?php echo e(number_format($ringkas['masuk']->total_nilai ?? 0, 0, ',', '.')); ?></div></div>
    <div class="col-md-6"><div class="alert alert-secondary mb-0">
        Total keluar: <strong><?php echo e(number_format($ringkas['keluar']->total_jumlah ?? 0, 0, ',', '.')); ?></strong> unit
        — Rp <?php echo e(number_format($ringkas['keluar']->total_nilai ?? 0, 0, ',', '.')); ?></div></div>
</div>

<div class="card shadow-sm"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead><tr><th>Tanggal</th><th>Produk</th><th>Tipe</th><th>Alasan</th><th class="text-end">Jumlah</th>
        <th class="text-end">Harga</th><th>Keterangan</th><th>Oleh</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($m->tanggal->format('d/m/Y')); ?></td>
            <td><?php echo e($m->product->nama); ?></td>
            <td><span class="badge <?php echo e($m->tipe === 'masuk' ? 'text-bg-success' : 'text-bg-secondary'); ?>"><?php echo e(ucfirst($m->tipe)); ?></span></td>
            <td><?php echo e(ucfirst(str_replace('_', ' ', $m->alasan))); ?></td>
            <td class="text-end"><?php echo e($m->jumlah); ?></td>
            <td class="text-end"><?php echo e(number_format($m->harga_satuan, 0, ',', '.')); ?></td>
            <td><?php echo e($m->keterangan ?? '-'); ?></td>
            <td><?php echo e($m->user->name ?? '-'); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">Tidak ada data.</td></tr>
    <?php endif; ?>
    </tbody>
</table></div></div>
<div class="mt-3"><?php echo e($movements->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/stok/index.blade.php ENDPATH**/ ?>