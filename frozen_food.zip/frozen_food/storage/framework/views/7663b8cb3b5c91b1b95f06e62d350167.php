<?php $__env->startSection('title', 'Edit Produk'); ?>
<?php $__env->startSection('content'); ?>
<h4 class="mb-1">Edit Produk</h4>
<p class="text-muted">Stok saat ini: <strong><?php echo e($product->stok); ?> <?php echo e($product->satuan); ?></strong> (ubah lewat menu Barang Masuk / Keluar)</p>
<div class="card shadow-sm"><div class="card-body">
    <form method="POST" action="<?php echo e(route('produk.update', $product)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('produk._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/produk/edit.blade.php ENDPATH**/ ?>