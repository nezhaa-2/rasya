<?php $__env->startSection('title', 'Produk'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Daftar Produk</h4>
    <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-primary">+ Tambah Produk</a>
</div>

<form class="row g-2 mb-3" method="GET">
    <div class="col-md-5"><input name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Cari nama / kode / kategori"></div>
    <div class="col-auto"><button class="btn btn-outline-primary">Cari</button></div>
</form>

<div class="card shadow-sm"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead><tr>
        <th>Kode</th><th>Nama</th><th>Kategori</th><th class="text-end">Harga Beli</th>
        <th class="text-end">Harga Jual</th><th class="text-end">Stok</th><th>Kadaluarsa</th><th></th>
    </tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->kode); ?></td>
            <td><?php echo e($p->nama); ?></td>
            <td><?php echo e($p->kategori ?? '-'); ?></td>
            <td class="text-end"><?php echo e(number_format($p->harga_beli, 0, ',', '.')); ?></td>
            <td class="text-end"><?php echo e(number_format($p->harga_jual, 0, ',', '.')); ?></td>
            <td class="text-end">
                <span class="badge <?php echo e($p->stok <= $p->stok_minimum ? 'text-bg-danger' : 'text-bg-success'); ?>"><?php echo e($p->stok); ?> <?php echo e($p->satuan); ?></span>
            </td>
            <td><?php echo e($p->tanggal_kadaluarsa?->format('d/m/Y') ?? '-'); ?></td>
            <td class="text-end text-nowrap">
                <a href="<?php echo e(route('produk.edit', $p)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                <form action="<?php echo e(route('produk.destroy', $p)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus produk ini beserta seluruh riwayat stoknya? Tidak bisa dikembalikan.')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">Belum ada produk.</td></tr>
    <?php endif; ?>
    </tbody>
</table></div></div>
<div class="mt-3"><?php echo e($products->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/produk/index.blade.php ENDPATH**/ ?>