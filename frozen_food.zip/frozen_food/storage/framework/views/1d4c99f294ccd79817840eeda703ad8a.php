
<?php $__env->startSection('title', 'Grafik Penjualan'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Grafik Penjualan</h4>
    <form method="GET" class="d-flex gap-2">
        <input type="month" name="bulan" value="<?php echo e($bulan); ?>" class="form-control" onchange="this.form.submit()">
        <a href="<?php echo e(route('stok.index')); ?>" class="btn btn-outline-secondary">Kembali</a>
    </form>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Total Terjual</div>
        <div class="fs-4 fw-bold"><?php echo e(number_format(array_sum($jumlah), 0, ',', '.')); ?> unit</div></div></div></div>
    <div class="col-md-6"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Total Pendapatan</div>
        <div class="fs-4 fw-bold">Rp <?php echo e(number_format(array_sum($nilai), 0, ',', '.')); ?></div></div></div></div>
</div>

<div class="card shadow-sm"><div class="card-body">
    <canvas id="grafik" height="110"></canvas>
</div></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('grafik'), {
    data: {
        labels: <?php echo json_encode($labels, 15, 512) ?>,
        datasets: [
            { type: 'bar',  label: 'Jumlah terjual', data: <?php echo json_encode($jumlah, 15, 512) ?>, backgroundColor: 'rgba(13,110,253,.6)', yAxisID: 'y' },
            { type: 'line', label: 'Pendapatan (Rp)', data: <?php echo json_encode($nilai, 15, 512) ?>, borderColor: '#198754', backgroundColor: '#198754', tension: .3, yAxisID: 'y1' }
        ]
    },
    options: {
        interaction: { mode: 'index', intersect: false },
        scales: {
            x:  { title: { display: true, text: 'Tanggal' } },
            y:  { beginAtZero: true, position: 'left',  title: { display: true, text: 'Unit' } },
            y1: { beginAtZero: true, position: 'right', title: { display: true, text: 'Rupiah' }, grid: { drawOnChartArea: false } }
        }
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/stok/grafik.blade.php ENDPATH**/ ?>