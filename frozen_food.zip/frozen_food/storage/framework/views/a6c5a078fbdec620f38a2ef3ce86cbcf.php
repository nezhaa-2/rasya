<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<h4 class="mb-3">Dashboard</h4>

<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Jumlah Produk</div>
        <div class="fs-3 fw-bold"><?php echo e($totalProduk); ?></div></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Nilai Stok (modal)</div>
        <div class="fs-3 fw-bold">Rp <?php echo e(number_format($nilaiStok, 0, ',', '.')); ?></div></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Potensi Nilai Jual (harga jual kotor)</div>
        <div class="fs-3 fw-bold">Rp <?php echo e(number_format($potensiJual, 0, ',', '.')); ?></div></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Barang Keluar Bulan Ini</div>
        <div class="fs-3 fw-bold"><?php echo e(number_format($keluarBulanIni, 0, ',', '.')); ?></div></div></div></div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm"><div class="card-header bg-warning-subtle fw-semibold">Stok Menipis</div>
        <ul class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $menipis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span><?php echo e($p->nama); ?></span>
                    <span class="badge text-bg-danger"><?php echo e($p->stok); ?> / min <?php echo e($p->stok_minimum); ?> <?php echo e($p->satuan); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item text-muted">Semua stok aman.</li>
            <?php endif; ?>
        </ul></div>
    </div>
    <div class="col-lg-6">
        <div class="card shadow-sm"><div class="card-header bg-danger-subtle fw-semibold">Hampir Kadaluarsa (≤ 30 hari)</div>
        <ul class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $kadaluarsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span><?php echo e($p->nama); ?> <small class="text-muted">(<?php echo e($p->stok); ?> <?php echo e($p->satuan); ?>)</small></span>
                    <span class="badge <?php echo e($p->tanggal_kadaluarsa->isPast() ? 'text-bg-danger' : 'text-bg-warning'); ?>">
                        <?php echo e($p->tanggal_kadaluarsa->format('d/m/Y')); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item text-muted">Tidak ada.</li>
            <?php endif; ?>
        </ul></div>
    </div>
    <div class="col-12">
        <div class="card shadow-sm"><div class="card-header fw-semibold">Transaksi Terakhir</div>
        <div class="table-responsive"><table class="table table-sm mb-0">
            <thead><tr><th>Tanggal</th><th>Produk</th><th>Tipe</th><th>Alasan</th><th class="text-end">Jumlah</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $terakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($m->tanggal->format('d/m/Y')); ?></td>
                    <td><?php echo e($m->product->nama); ?></td>
                    <td><span class="badge <?php echo e($m->tipe === 'masuk' ? 'text-bg-success' : 'text-bg-secondary'); ?>"><?php echo e(ucfirst($m->tipe)); ?></span></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $m->alasan))); ?></td>
                    <td class="text-end"><?php echo e($m->jumlah); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-muted text-center">Belum ada transaksi.</td></tr>
            <?php endif; ?>
            </tbody></table></div></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/dashboard.blade.php ENDPATH**/ ?>