<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Stok Frozen Food'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">❄ Stok Frozen Food</a>
        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('produk.index')); ?>">Produk</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('stok.create', 'masuk')); ?>">Barang Masuk</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('stok.create', 'keluar')); ?>">Barang Keluar</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('stok.index')); ?>">Riwayat</a></li>
            </ul>
           
        </div>
    </div>
</nav>

<main class="container pb-5">
    <?php if(session('success')): ?> <div class="alert alert-success"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <?php if(session('error')): ?> <div class="alert alert-danger"><?php echo e(session('error')); ?></div> <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-outline-light">Keluar</button>
</form>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\frozen\frozen_food\resources\views/layouts/main.blade.php ENDPATH**/ ?>