@extends('layouts.main')
@section('title', 'Dashboard')
@section('content')
<h4 class="mb-3">Dashboard</h4>

<div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Jumlah Produk</div>
        <div class="fs-3 fw-bold">{{ $totalProduk }}</div></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Nilai Stok (modal)</div>
        <div class="fs-3 fw-bold">Rp {{ number_format($nilaiStok, 0, ',', '.') }}</div></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Potensi Nilai Jual (harga jual kotor)</div>
        <div class="fs-3 fw-bold">Rp {{ number_format($potensiJual, 0, ',', '.') }}</div></div></div></div>
    <div class="col-md-3"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Barang Keluar Bulan Ini</div>
        <div class="fs-3 fw-bold">{{ number_format($keluarBulanIni, 0, ',', '.') }}</div></div></div></div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm"><div class="card-header bg-warning-subtle fw-semibold">Stok Menipis</div>
        <ul class="list-group list-group-flush">
            @forelse ($menipis as $p)
                <li class="list-group-item d-flex justify-content-between">
                    <span>{{ $p->nama }}</span>
                    <span class="badge text-bg-danger">{{ $p->stok }} / min {{ $p->stok_minimum }} {{ $p->satuan }}</span>
                </li>
            @empty
                <li class="list-group-item text-muted">Semua stok aman.</li>
            @endforelse
        </ul></div>
    </div>
    <div class="col-lg-6">
        <div class="card shadow-sm"><div class="card-header bg-danger-subtle fw-semibold">Hampir Kadaluarsa (≤ 30 hari)</div>
        <ul class="list-group list-group-flush">
            @forelse ($kadaluarsa as $p)
                <li class="list-group-item d-flex justify-content-between">
                    <span>{{ $p->nama }} <small class="text-muted">({{ $p->stok }} {{ $p->satuan }})</small></span>
                    <span class="badge {{ $p->tanggal_kadaluarsa->isPast() ? 'text-bg-danger' : 'text-bg-warning' }}">
                        {{ $p->tanggal_kadaluarsa->format('d/m/Y') }}</span>
                </li>
            @empty
                <li class="list-group-item text-muted">Tidak ada.</li>
            @endforelse
        </ul></div>
    </div>
    <div class="col-12">
        <div class="card shadow-sm"><div class="card-header fw-semibold">Transaksi Terakhir</div>
        <div class="table-responsive"><table class="table table-sm mb-0">
            <thead><tr><th>Tanggal</th><th>Produk</th><th>Tipe</th><th>Alasan</th><th class="text-end">Jumlah</th></tr></thead>
            <tbody>
            @forelse ($terakhir as $m)
                <tr>
                    <td>{{ $m->tanggal->format('d/m/Y') }}</td>
                    <td>{{ $m->product->nama }}</td>
                    <td><span class="badge {{ $m->tipe === 'masuk' ? 'text-bg-success' : 'text-bg-secondary' }}">{{ ucfirst($m->tipe) }}</span></td>
                    <td>{{ ucfirst(str_replace('_', ' ', $m->alasan)) }}</td>
                    <td class="text-end">{{ $m->jumlah }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-muted text-center">Belum ada transaksi.</td></tr>
            @endforelse
            </tbody></table></div></div>
    </div>
</div>
@endsection
