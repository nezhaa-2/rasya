@extends('layouts.main')
@section('title', 'Grafik Penjualan')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Grafik Penjualan</h4>
    <form method="GET" class="d-flex gap-2">
        <input type="month" name="bulan" value="{{ $bulan }}" class="form-control" onchange="this.form.submit()">
        <a href="{{ route('stok.index') }}" class="btn btn-outline-secondary">Kembali</a>
    </form>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-6"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Total Terjual</div>
        <div class="fs-4 fw-bold">{{ number_format(array_sum($jumlah), 0, ',', '.') }} unit</div></div></div></div>
    <div class="col-md-6"><div class="card shadow-sm"><div class="card-body">
        <div class="text-muted small">Total Pendapatan</div>
        <div class="fs-4 fw-bold">Rp {{ number_format(array_sum($nilai), 0, ',', '.') }}</div></div></div></div>
</div>

<div class="card shadow-sm"><div class="card-body">
    <canvas id="grafik" height="110"></canvas>
</div></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('grafik'), {
    data: {
        labels: @json($labels),
        datasets: [
            { type: 'bar',  label: 'Jumlah terjual', data: @json($jumlah), backgroundColor: 'rgba(13,110,253,.6)', yAxisID: 'y' },
            { type: 'line', label: 'Pendapatan (Rp)', data: @json($nilai), borderColor: '#198754', backgroundColor: '#198754', tension: .3, yAxisID: 'y1' }
        ]
    },
    options: {
        interaction: { mode: 'index', intersect: false },
        scales: {
            x:  { title: { display: true, text: 'Tanggal' } },
            y:  { beginAtZero: true, position: 'left',  title: { display: true, text: 'Unit' } },
            y1: { beginAtZero: true, position: 'right', title: { display: true, text: 'Rupiah' }, grid: { drawOnChartArea: false } }
        }
    }
});
</script>
@endsection