@extends('layouts.main')
@section('title', 'Riwayat Stok')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Riwayat Stok</h4>
    <div>
        <a href="{{ route('stok.create', 'masuk') }}" class="btn btn-success">+ Barang Masuk</a>
        <a href="{{ route('stok.create', 'keluar') }}" class="btn btn-secondary">+ Barang Keluar</a> <a href="{{ route('stok.grafik') }}" class="btn btn-outline-primary">Grafik Penjualan</a>
    </div>
</div>

<form method="GET" class="row g-2 mb-3">
    <div class="col-md-3">
        <select name="produk" class="form-select">
            <option value="">Semua produk</option>
            @foreach ($products as $p)
                <option value="{{ $p->id }}" @selected(request('produk') == $p->id)>{{ $p->nama }}</option>
            @endforeach
        </select>
    </div>
    <div class="col-md-2">
        <select name="tipe" class="form-select">
            <option value="">Semua tipe</option>
            <option value="masuk" @selected(request('tipe') === 'masuk')>Masuk</option>
            <option value="keluar" @selected(request('tipe') === 'keluar')>Keluar</option>
        </select>
    </div>
    <div class="col-md-2"><input type="date" name="dari" value="{{ request('dari') }}" class="form-control"></div>
    <div class="col-md-2"><input type="date" name="sampai" value="{{ request('sampai') }}" class="form-control"></div>
    <div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div>
</form>

<div class="row g-3 mb-3">
    <div class="col-md-6"><div class="alert alert-success mb-0">
        Total masuk: <strong>{{ number_format($ringkas['masuk']->total_jumlah ?? 0, 0, ',', '.') }}</strong> unit
        — Rp {{ number_format($ringkas['masuk']->total_nilai ?? 0, 0, ',', '.') }}</div></div>
    <div class="col-md-6"><div class="alert alert-secondary mb-0">
        Total keluar: <strong>{{ number_format($ringkas['keluar']->total_jumlah ?? 0, 0, ',', '.') }}</strong> unit
        — Rp {{ number_format($ringkas['keluar']->total_nilai ?? 0, 0, ',', '.') }}</div></div>
</div>

<div class="card shadow-sm"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead><tr><th>Tanggal</th><th>Produk</th><th>Tipe</th><th>Alasan</th><th class="text-end">Jumlah</th>
        <th class="text-end">Harga</th><th>Keterangan</th><th>Oleh</th></tr></thead>
    <tbody>
    @forelse ($movements as $m)
        <tr>
            <td>{{ $m->tanggal->format('d/m/Y') }}</td>
            <td>{{ $m->product->nama }}</td>
            <td><span class="badge {{ $m->tipe === 'masuk' ? 'text-bg-success' : 'text-bg-secondary' }}">{{ ucfirst($m->tipe) }}</span></td>
            <td>{{ ucfirst(str_replace('_', ' ', $m->alasan)) }}</td>
            <td class="text-end">{{ $m->jumlah }}</td>
            <td class="text-end">{{ number_format($m->harga_satuan, 0, ',', '.') }}</td>
            <td>{{ $m->keterangan ?? '-' }}</td>
            <td>{{ $m->user->name ?? '-' }}</td>
        </tr>
    @empty
        <tr><td colspan="8" class="text-center text-muted py-4">Tidak ada data.</td></tr>
    @endforelse
    </tbody>
</table></div></div>
<div class="mt-3">{{ $movements->links() }}</div>
@endsection
