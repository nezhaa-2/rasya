@extends('layouts.main')
@section('title', $tipe === 'masuk' ? 'Barang Masuk' : 'Barang Keluar')
@section('content')
<h4 class="mb-3">{{ $tipe === 'masuk' ? 'Catat Barang Masuk' : 'Catat Barang Keluar (Pengeluaran Produk)' }}</h4>
<div class="card shadow-sm"><div class="card-body">
<form method="POST" action="{{ route('stok.store') }}">
    @csrf
    <input type="hidden" name="tipe" value="{{ $tipe }}">
    <div class="row g-3">
        <div class="col-md-8">
            <label class="form-label">Produk</label>
            <select name="product_id" id="product" class="form-select" required>
                <option value="">-- pilih produk --</option>
                @foreach ($products as $p)
                    <option value="{{ $p->id }}" data-harga="{{ $tipe === 'masuk' ? $p->harga_beli : $p->harga_jual }}"
                        @selected(old('product_id') == $p->id)>
                        {{ $p->kode }} - {{ $p->nama }} (stok: {{ $p->stok }} {{ $p->satuan }})
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Tanggal</label>
            <input type="date" name="tanggal" class="form-control" value="{{ old('tanggal', now()->toDateString()) }}" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Alasan</label>
            <select name="alasan" class="form-select" required>
                @foreach ($alasan as $key => $label)
                    <option value="{{ $key }}" @selected(old('alasan') === $key)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Jumlah</label>
            <input type="number" min="1" name="jumlah" class="form-control" value="{{ old('jumlah') }}" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Harga Satuan (Rp)</label>
            <input type="number" min="0" name="harga_satuan" id="harga" class="form-control" value="{{ old('harga_satuan') }}">
            <div class="form-text">Kosongkan untuk memakai harga {{ $tipe === 'masuk' ? 'beli' : 'jual' }} produk.</div>
        </div>
        <div class="col-12">
            <label class="form-label">Keterangan</label>
            <input name="keterangan" class="form-control" maxlength="255" value="{{ old('keterangan') }}">
        </div>
    </div>
    <div class="mt-4">
        <button class="btn btn-primary">Simpan</button>
        <a href="{{ route('stok.index') }}" class="btn btn-link">Batal</a>
    </div>
</form>
</div></div>

<script>
    // isi otomatis harga saat produk dipilih
    document.getElementById('product').addEventListener('change', function () {
        const h = this.selectedOptions[0]?.dataset.harga;
        if (h !== undefined) document.getElementById('harga').value = h;
    });
</script>
@endsection
