@extends('layouts.main')
@section('title', 'Edit Produk')
@section('content')
<h4 class="mb-1">Edit Produk</h4>
<p class="text-muted">Stok saat ini: <strong>{{ $product->stok }} {{ $product->satuan }}</strong> (ubah lewat menu Barang Masuk / Keluar)</p>
<div class="card shadow-sm"><div class="card-body">
    <form method="POST" action="{{ route('produk.update', $product) }}">
        @csrf @method('PUT')
        @include('produk._form')
    </form>
</div></div>
@endsection
