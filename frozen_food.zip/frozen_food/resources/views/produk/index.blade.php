@extends('layouts.main')
@section('title', 'Produk')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Daftar Produk</h4>
    <a href="{{ route('produk.create') }}" class="btn btn-primary">+ Tambah Produk</a>
</div>

<form class="row g-2 mb-3" method="GET">
    <div class="col-md-5"><input name="q" value="{{ request('q') }}" class="form-control" placeholder="Cari nama / kode / kategori"></div>
    <div class="col-auto"><button class="btn btn-outline-primary">Cari</button></div>
</form>

<div class="card shadow-sm"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
    <thead><tr>
        <th>Kode</th><th>Nama</th><th>Kategori</th><th class="text-end">Harga Beli</th>
        <th class="text-end">Harga Jual</th><th class="text-end">Stok</th><th>Kadaluarsa</th><th></th>
    </tr></thead>
    <tbody>
    @forelse ($products as $p)
        <tr>
            <td>{{ $p->kode }}</td>
            <td>{{ $p->nama }}</td>
            <td>{{ $p->kategori ?? '-' }}</td>
            <td class="text-end">{{ number_format($p->harga_beli, 0, ',', '.') }}</td>
            <td class="text-end">{{ number_format($p->harga_jual, 0, ',', '.') }}</td>
            <td class="text-end">
                <span class="badge {{ $p->stok <= $p->stok_minimum ? 'text-bg-danger' : 'text-bg-success' }}">{{ $p->stok }} {{ $p->satuan }}</span>
            </td>
            <td>{{ $p->tanggal_kadaluarsa?->format('d/m/Y') ?? '-' }}</td>
            <td class="text-end text-nowrap">
                <a href="{{ route('produk.edit', $p) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
                <form action="{{ route('produk.destroy', $p) }}" method="POST" class="d-inline" onsubmit="return confirm('Hapus produk ini beserta seluruh riwayat stoknya? Tidak bisa dikembalikan.')">
                    @csrf @method('DELETE')
                    <button class="btn btn-sm btn-outline-danger">Hapus</button>
                </form>
            </td>
        </tr>
    @empty
        <tr><td colspan="8" class="text-center text-muted py-4">Belum ada produk.</td></tr>
    @endforelse
    </tbody>
</table></div></div>
<div class="mt-3">{{ $products->links() }}</div>
@endsection
