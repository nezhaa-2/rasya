@php($isEdit = isset($product))
<div class="row g-3">
    <div class="col-md-4">
        <label class="form-label">Kode</label>
        <input name="kode" class="form-control" value="{{ old('kode', $product->kode ?? '') }}" required>
    </div>
    <div class="col-md-8">
        <label class="form-label">Nama Produk</label>
        <input name="nama" class="form-control" value="{{ old('nama', $product->nama ?? '') }}" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Kategori</label>
        <input name="kategori" class="form-control" placeholder="Nugget, Sosis, Bakso, ..." value="{{ old('kategori', $product->kategori ?? '') }}">
    </div>
    <div class="col-md-6">
        <label class="form-label">Satuan</label>
        <input name="satuan" class="form-control" value="{{ old('satuan', $product->satuan ?? 'pack') }}" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Harga Beli (Rp)</label>
        <input type="number" min="0" name="harga_beli" class="form-control" value="{{ old('harga_beli', $product->harga_beli ?? 0) }}" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Harga Jual (Rp)</label>
        <input type="number" min="0" name="harga_jual" class="form-control" value="{{ old('harga_jual', $product->harga_jual ?? 0) }}" required>
    </div>
    @unless ($isEdit)
    <div class="col-md-4">
        <label class="form-label">Stok Awal</label>
        <input type="number" min="0" name="stok" class="form-control" value="{{ old('stok', 0) }}">
    </div>
    @endunless
    <div class="col-md-4">
        <label class="form-label">Stok Minimum (peringatan)</label>
        <input type="number" min="0" name="stok_minimum" class="form-control" value="{{ old('stok_minimum', $product->stok_minimum ?? 5) }}" required>
    </div>
    <div class="col-md-4">
        <label class="form-label">Tanggal Kadaluarsa</label>
        <input type="date" name="tanggal_kadaluarsa" class="form-control" value="{{ old('tanggal_kadaluarsa', isset($product) ? $product->tanggal_kadaluarsa?->format('Y-m-d') : '') }}">
    </div>
</div>
<div class="mt-4">
    <button class="btn btn-primary">Simpan</button>
    <a href="{{ route('produk.index') }}" class="btn btn-link">Batal</a>
</div>
