@extends('layouts.main')
@section('title', 'Tambah Produk')
@section('content')
<h4 class="mb-3">Tambah Produk</h4>
<div class="card shadow-sm"><div class="card-body">
    <form method="POST" action="{{ route('produk.store') }}">
        @csrf
        @include('produk._form')
    </form>
</div></div>
@endsection
