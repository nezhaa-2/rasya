<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    protected $fillable = [
        'kode', 'nama', 'kategori', 'satuan', 'harga_beli', 'harga_jual',
        'stok', 'stok_minimum', 'tanggal_kadaluarsa',
    ];

    protected $casts = [
        'tanggal_kadaluarsa' => 'date',
    ];

    public function movements(): HasMany
    {
        return $this->hasMany(StockMovement::class);
    }

    public function scopeMenipis($query)
    {
        return $query->whereColumn('stok', '<=', 'stok_minimum');
    }

    public function scopeHampirKadaluarsa($query, int $hari = 30)
    {
        return $query->whereNotNull('tanggal_kadaluarsa')
            ->where('stok', '>', 0)
            ->whereDate('tanggal_kadaluarsa', '<=', now()->addDays($hari));
    }
}
