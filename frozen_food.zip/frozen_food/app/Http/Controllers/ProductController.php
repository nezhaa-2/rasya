<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::query()
            ->when($request->q, fn ($q, $s) => $q->where(function ($w) use ($s) {
                $w->where('nama', 'like', "%{$s}%")
                  ->orWhere('kode', 'like', "%{$s}%")
                  ->orWhere('kategori', 'like', "%{$s}%");
            }))
            ->orderBy('nama')
            ->paginate(10)
            ->withQueryString();

        return view('produk.index', compact('products'));
    }

    public function create()
    {
        return view('produk.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate($this->rules());
        $data['stok'] = $data['stok'] ?? 0;

        DB::transaction(function () use ($data, $request) {
            $product = Product::create($data);

            if ($product->stok > 0) {
                StockMovement::create([
                    'product_id'   => $product->id,
                    'user_id'      => $request->user()->id,
                    'tipe'         => 'masuk',
                    'alasan'       => 'stok_awal',
                    'jumlah'       => $product->stok,
                    'harga_satuan' => $product->harga_beli,
                    'tanggal'      => now()->toDateString(),
                    'keterangan'   => 'Stok awal saat produk dibuat',
                ]);
            }
        });

        return redirect()->route('produk.index')->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(Product $product)
    {
        return view('produk.edit', compact('product'));
    }

    public function update(Request $request, Product $product)
    {
        $data = $request->validate($this->rules($product));
        unset($data['stok']); // stok hanya berubah lewat transaksi masuk/keluar

        $product->update($data);

        return redirect()->route('produk.index')->with('success', 'Produk berhasil diperbarui.');
    }

   public function destroy(Product $product)
{
    DB::transaction(function () use ($product) {
        $product->movements()->delete();
        $product->delete();
    });

    return redirect()->route('produk.index')
        ->with('success', 'Produk dan seluruh riwayat stoknya dihapus.');
}

    private function rules(?Product $product = null): array
    {
        return [
            'kode'               => ['required', 'string', 'max:30', Rule::unique('products', 'kode')->ignore($product)],
            'nama'               => ['required', 'string', 'max:255'],
            'kategori'           => ['nullable', 'string', 'max:100'],
            'satuan'             => ['required', 'string', 'max:20'],
            'harga_beli'         => ['required', 'integer', 'min:0'],
            'harga_jual'         => ['required', 'integer', 'min:0'],
            'stok'               => ['nullable', 'integer', 'min:0'],
            'stok_minimum'       => ['required', 'integer', 'min:0'],
            'tanggal_kadaluarsa' => ['nullable', 'date'],
        ];
    }
}
