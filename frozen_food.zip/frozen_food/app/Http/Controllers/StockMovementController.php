<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class StockMovementController extends Controller
{
    public const ALASAN = [
        'masuk'  => ['pembelian' => 'Pembelian / restok', 'retur' => 'Retur pelanggan', 'penyesuaian' => 'Penyesuaian stok'],
        'keluar' => ['penjualan' => 'Penjualan', 'rusak' => 'Rusak / mencair', 'kadaluarsa' => 'Kadaluarsa', 'penyesuaian' => 'Penyesuaian stok'],
    ];

    public function index(Request $request)
    {
        $movements = StockMovement::with(['product', 'user'])
            ->when($request->tipe, fn ($q, $v) => $q->where('tipe', $v))
            ->when($request->dari, fn ($q, $v) => $q->whereDate('tanggal', '>=', $v))
            ->when($request->sampai, fn ($q, $v) => $q->whereDate('tanggal', '<=', $v))
            ->when($request->produk, fn ($q, $v) => $q->where('product_id', $v))
            ->latest('tanggal')->latest('id')
            ->paginate(15)
            ->withQueryString();

        // ringkasan sesuai filter tanggal & produk
        $ringkas = StockMovement::query()
            ->when($request->dari, fn ($q, $v) => $q->whereDate('tanggal', '>=', $v))
            ->when($request->sampai, fn ($q, $v) => $q->whereDate('tanggal', '<=', $v))
            ->when($request->produk, fn ($q, $v) => $q->where('product_id', $v))
            ->selectRaw('tipe, SUM(jumlah) as total_jumlah, SUM(jumlah * harga_satuan) as total_nilai')
            ->groupBy('tipe')->get()->keyBy('tipe');

        return view('stok.index', [
            'movements' => $movements,
            'ringkas'   => $ringkas,
            'products'  => Product::orderBy('nama')->get(['id', 'nama']),
        ]);
    }

    public function grafik(Request $request)
    {
    $request->validate(['bulan' => ['nullable', 'date_format:Y-m']]);

    $bulan = $request->input('bulan', now()->format('Y-m'));
    $awal  = \Carbon\Carbon::createFromFormat('Y-m-d', $bulan . '-01')->startOfMonth();
    $akhir = $awal->copy()->endOfMonth();

    $data = StockMovement::where('tipe', 'keluar')
        ->where('alasan', 'penjualan')
        ->whereBetween('tanggal', [$awal->toDateString(), $akhir->toDateString()])
        ->selectRaw('tanggal, SUM(jumlah) as total_jumlah, SUM(jumlah * harga_satuan) as total_nilai')
        ->groupBy('tanggal')
        ->get()
        ->keyBy(fn ($r) => $r->tanggal->format('Y-m-d'));

    $labels = $jumlah = $nilai = [];
    for ($d = $awal->copy(); $d->lte($akhir); $d->addDay()) {
        $k = $d->format('Y-m-d');
        $labels[] = $d->format('d');
        $jumlah[] = (int) ($data[$k]->total_jumlah ?? 0);
        $nilai[]  = (int) ($data[$k]->total_nilai ?? 0);
    }

    return view('stok.grafik', [
        'bulan'  => $bulan,
        'labels' => $labels,
        'jumlah' => $jumlah,
        'nilai'  => $nilai,
    ]);
}

    public function create(string $tipe)
    {
        abort_unless(in_array($tipe, ['masuk', 'keluar']), 404);

        return view('stok.create', [
            'tipe'     => $tipe,
            'alasan'   => self::ALASAN[$tipe],
            'products' => Product::orderBy('nama')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $tipe = $request->input('tipe');
        abort_unless(in_array($tipe, ['masuk', 'keluar']), 422);

        $data = $request->validate([
            'tipe'         => ['required', Rule::in(['masuk', 'keluar'])],
            'product_id'   => ['required', 'exists:products,id'],
            'alasan'       => ['required', Rule::in(array_keys(self::ALASAN[$tipe]))],
            'jumlah'       => ['required', 'integer', 'min:1'],
            'harga_satuan' => ['nullable', 'integer', 'min:0'],
            'tanggal'      => ['required', 'date'],
            'keterangan'   => ['nullable', 'string', 'max:255'],
        ]);

        DB::transaction(function () use ($data, $request) {
            // kunci baris produk agar stok tidak bentrok saat transaksi bersamaan
            $product = Product::lockForUpdate()->findOrFail($data['product_id']);

            if ($data['tipe'] === 'keluar') {
                if ($data['jumlah'] > $product->stok) {
                    throw ValidationException::withMessages([
                        'jumlah' => "Stok {$product->nama} tidak cukup (tersisa {$product->stok} {$product->satuan}).",
                    ]);
                }
                $product->stok -= $data['jumlah'];
                $data['harga_satuan'] = $data['harga_satuan'] ?? $product->harga_jual;
            } else {
                $product->stok += $data['jumlah'];
                $data['harga_satuan'] = $data['harga_satuan'] ?? $product->harga_beli;
            }

            $product->save();

            StockMovement::create($data + ['user_id' => $request->user()?->id]);
        });

        return redirect()->route('stok.index')->with('success', 'Transaksi barang ' . $tipe . ' berhasil dicatat.');
    }
}
