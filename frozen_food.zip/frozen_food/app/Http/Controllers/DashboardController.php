<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockMovement;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard', [
            'totalProduk'    => Product::count(),
            'nilaiStok'      => (int) Product::sum(DB::raw('stok * harga_beli')),
            'potensiJual' => (int) Product::sum(DB::raw('stok * harga_jual')),
            'keluarBulanIni' => (int) StockMovement::where('tipe', 'keluar')
                ->whereMonth('tanggal', now()->month)
                ->whereYear('tanggal', now()->year)
                ->sum('jumlah'),
            'menipis'        => Product::menipis()->orderBy('stok')->limit(10)->get(),
            'kadaluarsa'     => Product::hampirKadaluarsa()->orderBy('tanggal_kadaluarsa')->limit(10)->get(),
            'terakhir'       => StockMovement::with('product')->latest()->limit(10)->get(),
        ]);
    }
}
