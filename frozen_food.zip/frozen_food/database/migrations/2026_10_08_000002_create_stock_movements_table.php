<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->restrictOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->enum('tipe', ['masuk', 'keluar']);
            $table->string('alasan', 30);                 // pembelian, penjualan, rusak, kadaluarsa, dll
            $table->unsignedInteger('jumlah');
            $table->unsignedBigInteger('harga_satuan')->default(0);
            $table->date('tanggal');
            $table->string('keterangan')->nullable();
            $table->timestamps();

            $table->index(['tipe', 'tanggal']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_movements');
    }
};
